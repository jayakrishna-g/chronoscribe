from typing import Any

from app.modules.room.model import Room

import asyncio


class Cache:
    def __init__(self):
        self.cache = {}
        self.sync_funcs = {}

    def get(self, key: str) -> Any:
        return self.cache.get(key)

    def set(self, key: str, value: Any, ttl: int = 120, sync_func: Any = None) -> None:
        self.cache[key] = value
        if sync_func:
            self.register_sync_func(key, sync_func, ttl)

    def delete(self, key: str) -> None:
        if key in self.cache:
            del self.cache[key]

    def clear(self) -> None:
        self.cache = {}

    def sync_helper(self, ttl: int, callback: Any):
        async def sync():
            while True:
                await callback()
                await asyncio.sleep(ttl)

        asyncio.get_event_loop().create_task(sync())

    def register_sync_func(self, key: str, sync_func: Any, ttl: int) -> None:
        self.sync_funcs[key] = (sync_func, ttl)
        self.sync_helper(ttl, sync_func)
